var btnup = document.getElementById("upbtn");



btnup.onclick = function () {
    document.getElementById("signupmodal").style.display = "block";
}


document.body.style.backgroundColor = "#ecd7c0"

// document.querySelector("html").style.backgroundColor = "#d2e6a5"
